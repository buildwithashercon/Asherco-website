export default function Services() {
  return (
    <main>
      <h1>Our Services</h1>
      <p>We offer a wide range of handcrafted and rustic building solutions.</p>
    </main>
  );
}
