export default function Contact() {
  return (
    <main>
      <h1>Contact Us</h1>
      <p>Phone: 0742949226</p>
      <p>Email: cleanwellchizeya.56@gmail.com</p>
      <p>Address: Lekker Water Industrial</p>
    </main>
  );
}
