export default function Projects() {
  return (
    <main>
      <h1>Our Projects</h1>
      <p>Gallery and showcase of completed work coming soon.</p>
    </main>
  );
}
